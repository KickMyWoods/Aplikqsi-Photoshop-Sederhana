import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("PhotoShop App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1080, 600);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);

        JMenuBar menuBar = new JMenuBar();
        frame.setJMenuBar(menuBar);

        FileMenu fileMenu = new FileMenu(frame);
        EditMenu editMenu = new EditMenu(frame);
        FilterMenu filterMenu = new FilterMenu(frame);



        JMenuItem undoMenuItem = new JMenuItem("Undo");

        // Mendapatkan dimensi dari tombol pada menu "File"
        Dimension preferredSize = fileMenu.getMenu().getPreferredSize();


        // Mengatur dimensi tombol "Undo" agar sama dengan tombol "File"
        undoMenuItem.setMaximumSize(preferredSize);

        undoMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editMenu.undo();
                filterMenu.undo();
            }
        });

        menuBar.add(fileMenu.getMenu());
        menuBar.add(editMenu.getMenu());
        menuBar.add(filterMenu.getMenu());
        menuBar.add(undoMenuItem);


        frame.setVisible(true);
    }
}
